package aplikacija;

public class Global {
	public static boolean isLoggedIn = false;
	public static String email;
	
}